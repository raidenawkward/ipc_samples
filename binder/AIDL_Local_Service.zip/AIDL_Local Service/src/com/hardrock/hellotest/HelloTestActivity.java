package com.hardrock.hellotest;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class HelloTestActivity extends Activity {

    IMyInterface mMyInterface;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // ���� ���� (Bind)
        Intent intent = new Intent(HelloTestActivity.this, MyService.class);
        bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
        
        Button button = (Button) findViewById(R.id.Button01);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	TextView text = (TextView) findViewById(R.id.TextView01);

                  String result = "";
                  try {
                      // AIDL Interface�� ������ �޼��带 ȣ���Ͽ� ����Ѵ�.
                      result = mMyInterface.sayHello("JamesKim");
                  } catch (RemoteException e) {
                      e.printStackTrace();
                  }

                  text.setText(result);		
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // ���� ���� ���� (Unbind)
        unbindService(mConnection);
        mConnection = null;
    }

    // ���� ����(Bind)�� ���� �̺�Ʈ�� �����ϴ� ServiceConnection ��ü
    private ServiceConnection mConnection = new ServiceConnection() {

        public void onServiceConnected(ComponentName className, IBinder service) {
            // ��Ƽ��Ƽ�� ���ϴ� ���񽺿� ����Ǿ��� �� ȣ��ȴ�.
            Log.d("MY_TAG", "onServiceConnected()");

            // AIDL Interface�� ���� ����� �� �� �ֵ��� �� �ش�.
            mMyInterface = IMyInterface.Stub.asInterface((IBinder) service);

            Toast.makeText(HelloTestActivity.this, "Service Connected",
                Toast.LENGTH_SHORT).show();
        }

        public void onServiceDisconnected(ComponentName className) {
            // Unexpectedly disconnected, we should never see this happen.
            Log.d("MY_TAG", "onServiceDisconnected()");

            mMyInterface = null;

            Toast.makeText(HelloTestActivity.this, "Service Disconnected",
                Toast.LENGTH_SHORT).show();
        }
        
    };

}
