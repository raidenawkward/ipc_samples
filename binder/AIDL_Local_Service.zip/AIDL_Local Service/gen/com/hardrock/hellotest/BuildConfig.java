/** Automatically generated file. DO NOT MODIFY */
package com.hardrock.hellotest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}