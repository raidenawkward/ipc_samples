package com.hardrock.hellotest;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

public class MyService extends Service {

    private final IBinder mBinder = new MyBinder();

    // Class for clients to access.
    public class MyBinder extends Binder {
        MyService getService() {
            return MyService.this;
        }
    }

    public void test(int x) {
        Log.d("MY_TAG", "test : " + x);
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d("MY_TAG", "Service onBind()");
        return mBinder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("MY_TAG", "Service onCreate()");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("MY_TAG", "Service onStartCommand()");

        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("MY_TAG", "Service onDestory()");
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d("MY_TAG", "Service onUnbind()");
        return super.onUnbind(intent);
    }

    @Override
    public void onRebind(Intent intent) {
        super.onRebind(intent);
        Log.d("MY_TAG", "Service onRebind()");
    }

}
