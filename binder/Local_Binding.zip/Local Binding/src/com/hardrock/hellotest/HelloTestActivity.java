package com.hardrock.hellotest;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class HelloTestActivity extends Activity {

    private boolean mIsBound;
    private MyService mBoundService;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Button btn_start = (Button) findViewById(R.id.Button01);
        btn_start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	// Start Service
                Intent intent = new Intent(HelloTestActivity.this, MyService.class);
                startService(intent);
            }
        });        

        Button btn_stop = (Button) findViewById(R.id.Button02);
        btn_stop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	// Stop Service
                Intent intent = new Intent(HelloTestActivity.this, MyService.class);
                stopService(intent);
            }
        }); 

        Button btn_bind = (Button) findViewById(R.id.Button03);
        btn_bind.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	// Bind Service
                Intent intent = new Intent(HelloTestActivity.this, MyService.class);
                bindService(intent, mConnection, Context.BIND_AUTO_CREATE);

                mIsBound = true;				
            }
        });
        
        Button btn_unbind = (Button) findViewById(R.id.Button04);
        btn_unbind.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
            	// Unbind Service
                if (mIsBound) {
                    unbindService(mConnection);

                    mIsBound = false;
                }
            }
        });

    }
    
    // The ServiceConnection Instance listen the events about Service Connection (Bind).
    // Defines callbacks for service binding, passed to bindService()
    private ServiceConnection mConnection = new ServiceConnection() {

        public void onServiceConnected(ComponentName className, IBinder service) {
        	// We've bound to LocalService, cast the IBinder and get LocalService instance
            Log.d("MY_TAG", "onServiceConnected()");

            mBoundService = ((MyService.MyBinder) service).getService();
            mBoundService.test(3);

            Toast.makeText(HelloTestActivity.this, "Service Connected",
                Toast.LENGTH_SHORT).show();
        }

        public void onServiceDisconnected(ComponentName className) {
            // Unexpectedly disconnected
            Log.d("MY_TAG", "onServiceDisconnected()");

            mBoundService = null;

            Toast.makeText(HelloTestActivity.this, "Service Disconnected",
                Toast.LENGTH_SHORT).show();
        }
        
    };

}
