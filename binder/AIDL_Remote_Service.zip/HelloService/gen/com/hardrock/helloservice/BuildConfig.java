/** Automatically generated file. DO NOT MODIFY */
package com.hardrock.helloservice;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}